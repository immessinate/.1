package com.example.simpleweather.ui.screen

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.simpleweather.data.model.CurrentCondition
import com.example.simpleweather.data.model.WeatherDay

// 天气状态对应的背景渐变
private fun weatherBackground(weatherCode: String?): Brush {
    return when (weatherCode) {
        "113" -> Brush.verticalGradient(  // 晴天
            colors = listOf(Color(0xFF4A90D9), Color(0xFF87CEEB))
        )
        "116" -> Brush.verticalGradient(  // 多云
            colors = listOf(Color(0xFF7B9EC7), Color(0xFFB0C4DE))
        )
        in listOf("119", "122") -> Brush.verticalGradient(  // 阴天
            colors = listOf(Color(0xFF78909C), Color(0xFFB0BEC5))
        )
        in listOf("176", "263", "266", "293", "296", "299", "302", "305", "308", "311") -> Brush.verticalGradient(  // 雨
            colors = listOf(Color(0xFF455A64), Color(0xFF607D8B))
        )
        in listOf("179", "227", "230", "323", "326", "329", "332", "338", "371") -> Brush.verticalGradient(  // 雪
            colors = listOf(Color(0xFF78909C), Color(0xFFCFD8DC))
        )
        "200" -> Brush.verticalGradient(  // 雷暴
            colors = listOf(Color(0xFF37474F), Color(0xFF546E7A))
        )
        else -> Brush.verticalGradient(
            colors = listOf(Color(0xFF4A90D9), Color(0xFF87CEEB))
        )
    }
}

// 天气图标映射
private fun weatherIcon(weatherCode: String?): ImageVector {
    return when (weatherCode) {
        "113" -> Icons.Filled.WbSunny
        "116" -> Icons.Filled.PartlyCloudyDay
        "119" -> Icons.Filled.Cloud
        "122" -> Icons.Filled.CloudySnowing
        in listOf("176", "263", "266", "293", "296", "299", "302", "305", "308", "311") -> Icons.Filled.WaterDrop
        in listOf("179", "227", "230", "323", "326", "329", "332", "338", "371") -> Icons.Filled.AcUnit
        "200" -> Icons.Filled.Thunderstorm
        else -> Icons.Filled.WbSunny
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherScreen(
    viewModel: WeatherViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val focusManager = LocalFocusManager.current
    var searchText by remember { mutableStateOf("深圳") }

    val weather = uiState.weather
    val current = weather?.currentCondition?.firstOrNull()
    val weatherCode = current?.weatherCode
    val bgBrush = weatherBackground(weatherCode)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(brush = bgBrush)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .systemBarsPadding()
        ) {
            // 标题
            Text(
                text = "天气预报",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // 搜索栏
            OutlinedTextField(
                value = searchText,
                onValueChange = { searchText = it },
                placeholder = { Text("输入城市名（中文/英文/拼音）", color = Color.White.copy(alpha = 0.7f)) },
                leadingIcon = {
                    Icon(Icons.Filled.Search, "搜索", tint = Color.White)
                },
                trailingIcon = {
                    IconButton(onClick = {
                        viewModel.searchWeather(searchText)
                        focusManager.clearFocus()
                    }) {
                        Icon(
                            Icons.Filled.Send,
                            "确认搜索",
                            tint = Color.White
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    viewModel.searchWeather(searchText)
                    focusManager.clearFocus()
                }),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Color.White.copy(alpha = 0.8f),
                    unfocusedBorderColor = Color.White.copy(alpha = 0.5f),
                    cursorColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 错误信息
            AnimatedVisibility(visible = uiState.errorMessage != null) {
                uiState.errorMessage?.let { msg ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = Color.Red.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = msg,
                            color = Color.White,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            // 加载中
            if (uiState.isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Color.White)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("正在获取天气数据...", color = Color.White)
                    }
                }
            }

            // 当前天气卡片
            AnimatedVisibility(
                visible = current != null && !uiState.isLoading,
                enter = fadeIn() + slideInVertically()
            ) {
                current?.let { CurrentWeatherCard(it, uiState.cityName) }
            }

            // 3日预报
            AnimatedVisibility(
                visible = weather?.weather != null && !uiState.isLoading,
                enter = fadeIn() + slideInVertically()
            ) {
                weather?.weather?.let { forecast ->
                    ForecastSection(forecast.take(3))
                }
            }

            Spacer(modifier = Modifier.height(80.dp)) // 底部留白
        }
    }
}

@Composable
private fun CurrentWeatherCard(current: CurrentCondition, cityName: String) {
    val weatherCode = current.weatherCode
    val desc = current.weatherDesc?.firstOrNull()?.value ?: "未知"
    val temp = current.tempC ?: "--"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.2f)
        )
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 城市名
            Text(
                text = cityName,
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )

            // 天气图标
            Icon(
                imageVector = weatherIcon(weatherCode),
                contentDescription = desc,
                modifier = Modifier
                    .size(80.dp)
                    .padding(8.dp),
                tint = Color.White
            )

            // 温度
            Text(
                text = "${temp}°C",
                fontSize = 64.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            // 天气描述
            Text(
                text = desc,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White.copy(alpha = 0.9f)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // 详情网格
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                WeatherDetailItem(
                    icon = Icons.Filled.Opacity,
                    label = "湿度",
                    value = "${current.humidity ?: "--"}%"
                )
                WeatherDetailItem(
                    icon = Icons.Filled.Air,
                    label = "风速",
                    value = "${current.windspeedKmph ?: "--"} km/h"
                )
                WeatherDetailItem(
                    icon = Icons.Filled.DewPoint,
                    label = "体感",
                    value = "${current.feelsLikeC ?: "--"}°C"
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                WeatherDetailItem(
                    icon = Icons.Filled.Visibility,
                    label = "能见度",
                    value = "${current.visibility ?: "--"} km"
                )
                WeatherDetailItem(
                    icon = Icons.Filled.Speed,
                    label = "气压",
                    value = "${current.pressure ?: "--"} hPa"
                )
                WeatherDetailItem(
                    icon = Icons.Filled.LightMode,
                    label = "紫外线",
                    value = current.uvIndex ?: "--"
                )
            }
        }
    }
}

@Composable
private fun WeatherDetailItem(
    icon: ImageVector,
    label: String,
    value: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(80.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = Color.White.copy(alpha = 0.8f),
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
        Text(
            text = label,
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 11.sp
        )
    }
}

@Composable
private fun ForecastSection(days: List<WeatherDay>) {
    Text(
        text = "未来预报",
        style = MaterialTheme.typography.titleLarge,
        color = Color.White,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 20.dp, bottom = 12.dp)
    )

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(days) { day ->
            ForecastDayCard(day)
        }
    }
}

@Composable
private fun ForecastDayCard(day: WeatherDay) {
    val maxTemp = day.maxtempC ?: "--"
    val minTemp = day.mintempC ?: "--"
    val avgTemp = day.avgtempC ?: "--"
    val desc = day.hourly?.firstOrNull()?.weatherDesc?.firstOrNull()?.value ?: "未知"
    val code = day.hourly?.firstOrNull()?.weatherCode
    val date = formatDate(day.date)

    Card(
        modifier = Modifier.width(150.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.2f)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 日期
            Text(
                text = date,
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 天气图标
            Icon(
                imageVector = weatherIcon(code),
                contentDescription = desc,
                tint = Color.White,
                modifier = Modifier.size(36.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 温度
            Text(
                text = "${avgTemp}°",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            // 高低温
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "↓${minTemp}°",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 13.sp
                )
                Text(
                    text = "↑${maxTemp}°",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // 描述
            Text(
                text = desc,
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

/**
 * 格式化日期显示
 */
private fun formatDate(dateStr: String?): String {
    if (dateStr == null) return "--"
    // wttr.in 返回格式: "2024-01-15"
    val parts = dateStr.split("-")
    return if (parts.size == 3) {
        "${parts[1]}月${parts[2]}日"
    } else dateStr
}
