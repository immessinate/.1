package com.example.simpleweather.ui.theme

import androidx.compose.ui.graphics.Color

// 天气主题色
val SunnyYellow = Color(0xFFFFB347)
val CloudGray = Color(0xFFB0BEC5)
val RainBlue = Color(0xFF4A90D9)
val SnowWhite = Color(0xFFE8EAF6)
val NightDark = Color(0xFF1A237E)

// Material3 配色
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650A4)
val PurpleGrey40 = Color(0xFF625B71)
val Pink40 = Color(0xFF7D5260)

// 背景渐变色
val SkyBlueStart = Color(0xFF4A90D9)
val SkyBlueEnd = Color(0xFF1E88E5)
val WarmStart = Color(0xFFFF9800)
val WarmEnd = Color(0xFFFF5722)
