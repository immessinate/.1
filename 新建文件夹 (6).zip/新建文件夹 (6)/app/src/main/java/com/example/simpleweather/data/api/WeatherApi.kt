package com.example.simpleweather.data.api

import com.example.simpleweather.data.model.WeatherResponse
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface WeatherApi {

    @GET("{city}")
    suspend fun getWeather(
        @Path("city") city: String,
        @Query("format") format: String = "j1"
    ): WeatherResponse
}
