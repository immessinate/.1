package com.example.simpleweather.data.model

import com.google.gson.annotations.SerializedName

/**
 * wttr.in API 返回的完整天气数据
 */
data class WeatherResponse(
    @SerializedName("current_condition")
    val currentCondition: List<CurrentCondition>?,
    val weather: List<WeatherDay>?
)

data class CurrentCondition(
    @SerializedName("temp_C") val tempC: String?,
    @SerializedName("temp_F") val tempF: String?,
    @SerializedName("weatherCode") val weatherCode: String?,
    @SerializedName("weatherDesc") val weatherDesc: List<WeatherDesc>?,
    val humidity: String?,
    @SerializedName("windspeedKmph") val windspeedKmph: String?,
    @SerializedName("winddir16Point") val winddir16Point: String?,
    @SerializedName("FeelsLikeC") val feelsLikeC: String?,
    val visibility: String?,
    val pressure: String?,
    @SerializedName("uvIndex") val uvIndex: String?
)

data class WeatherDesc(
    val value: String?
)

data class WeatherDay(
    val date: String?,
    @SerializedName("mintempC") val mintempC: String?,
    @SerializedName("maxtempC") val maxtempC: String?,
    @SerializedName("avgtempC") val avgtempC: String?,
    val hourly: List<HourlyWeather>?
)

data class HourlyWeather(
    @SerializedName("weatherCode") val weatherCode: String?,
    @SerializedName("weatherDesc") val weatherDesc: List<WeatherDesc>?,
    @SerializedName("tempC") val tempC: String?,
    @SerializedName("windspeedKmph") val windspeedKmph: String?,
    val humidity: String?
)
