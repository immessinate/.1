package com.example.simpleweather.ui.screen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.simpleweather.data.api.RetrofitClient
import com.example.simpleweather.data.model.WeatherResponse
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class WeatherUiState(
    val isLoading: Boolean = false,
    val weather: WeatherResponse? = null,
    val cityName: String = "深圳",
    val errorMessage: String? = null
)

class WeatherViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(WeatherUiState())
    val uiState: StateFlow<WeatherUiState> = _uiState.asStateFlow()

    private val api = RetrofitClient.weatherApi

    fun searchWeather(city: String) {
        if (city.isBlank()) return

        _uiState.value = _uiState.value.copy(
            isLoading = true,
            cityName = city,
            errorMessage = null
        )

        viewModelScope.launch {
            try {
                val response = api.getWeather(city = city)
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    weather = response
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "查询失败: ${e.localizedMessage ?: "未知错误"}"
                )
            }
        }
    }
}
